#include "ai_estimator.hpp"

AIEstimator::AIEstimator()
    : actualTime(0), lastLevel(0) {}

double AIEstimator::estimateTime(double flow2, double deepakLevel) {
    double remaining = 100.0 - deepakLevel;
    if (flow2 <= 0.01)
        return -1.0;
    return (remaining * 1000.0) / flow2;
}

void AIEstimator::trackActualTime(double deepakLevel) {
    if (deepakLevel > lastLevel) {
        actualTime += 1.0;  // 1 min increment per loop
        lastLevel = deepakLevel;
    }
}

double AIEstimator::getActualTime() const {
    return actualTime;  // ✅ Add this
}
