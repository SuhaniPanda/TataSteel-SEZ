#ifndef CLEARWATERGUI_HPP
#define CLEARWATERGUI_HPP

#include <QWidget>
#include <QLabel>
#include <QPushButton>
#include <QProgressBar>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QPixmap>
#include <QFrame>

class ClearWaterGUI : public QWidget {
    Q_OBJECT

public:
    ClearWaterGUI(QWidget *parent = nullptr);
    void updateReadings(double fm1, double fm2, double estTime, double actualTime, double deepakLevel, bool pumpOn);
    void updatePumpStatus(bool on);

signals:
    void startRequested();
    void stopRequested();

private slots:
    void onStartClicked();
    void onStopClicked();

private:
    QLabel *flow1Label;
    QLabel *flow2Label;
    QLabel *estTimeLabel;
    QLabel *actualTimeLabel;
    QLabel *deepakLevelLabel;
    QLabel *pumpStatusLabel;
    QProgressBar *progressBar;
    QLabel *logoLabel;

    QPushButton *startButton;
    QPushButton *stopButton;
};

#endif // CLEARWATERGUI_HPP
