#pragma once

class FlowLogic {
public:
    double detectLeak(double flow1, double flow2);
};
