#include "gui.hpp"
#include <QFont>
#include <QApplication>

ClearWaterGUI::ClearWaterGUI(QWidget *parent)
    : QWidget(parent)
{
    setWindowTitle("💧 Clear Water Transfer Pump System");
    resize(700, 450);
    setStyleSheet("QWidget { background-color: #121212; color: white; font-family: Segoe UI; font-size: 12pt; }"
                  "QPushButton { background-color: #1976D2; color: white; padding: 6px 14px; border-radius: 6px; }"
                  "QPushButton:hover { background-color: #1565C0; }"
                  "QLabel { margin: 4px; }"
                  "QProgressBar { height: 25px; border: 1px solid #555; border-radius: 5px; text-align: center; }"
                  "QProgressBar::chunk { background-color: #00C853; width: 1px; }");

    logoLabel = new QLabel();
    logoLabel->setPixmap(QPixmap("src/logo.png").scaled(60, 60, Qt::KeepAspectRatio));
    logoLabel->setFixedSize(60, 60);

    QLabel *title = new QLabel("Clear Water Pump Dashboard");
    QFont titleFont("Segoe UI", 16, QFont::Bold);
    title->setFont(titleFont);
    title->setStyleSheet("color: #00B0FF;");
    title->setAlignment(Qt::AlignCenter);

    flow1Label = new QLabel("Flowmeter 1: -- m³/hr");
    flow2Label = new QLabel("Flowmeter 2: -- m³/hr");
    estTimeLabel = new QLabel("Estimated Time: -- min");
    actualTimeLabel = new QLabel("Actual Time: -- min");
    deepakLevelLabel = new QLabel("Receiver Tank Level: -- %");
    pumpStatusLabel = new QLabel("Pump Status: --");

    progressBar = new QProgressBar();
    progressBar->setMinimum(0);
    progressBar->setMaximum(100);
    progressBar->setValue(0);
    progressBar->setTextVisible(true);

    startButton = new QPushButton("Start Pump");
    stopButton = new QPushButton("Stop Pump");

    QHBoxLayout *topLayout = new QHBoxLayout();
    topLayout->addWidget(logoLabel);
    topLayout->addWidget(title);

    QGridLayout *grid = new QGridLayout();
    grid->addWidget(flow1Label, 0, 0);
    grid->addWidget(flow2Label, 0, 1);
    grid->addWidget(estTimeLabel, 1, 0);
    grid->addWidget(actualTimeLabel, 1, 1);
    grid->addWidget(deepakLevelLabel, 2, 0);
    grid->addWidget(pumpStatusLabel, 2, 1);

    QHBoxLayout *btnLayout = new QHBoxLayout();
    btnLayout->addWidget(startButton);
    btnLayout->addWidget(stopButton);
    btnLayout->setAlignment(Qt::AlignCenter);

    QVBoxLayout *mainLayout = new QVBoxLayout();
    mainLayout->addLayout(topLayout);
    mainLayout->addSpacing(10);
    mainLayout->addLayout(grid);
    mainLayout->addSpacing(15);
    mainLayout->addWidget(progressBar);
    mainLayout->addSpacing(15);
    mainLayout->addLayout(btnLayout);
    setLayout(mainLayout);

    connect(startButton, &QPushButton::clicked, this, &ClearWaterGUI::onStartClicked);
    connect(stopButton, &QPushButton::clicked, this, &ClearWaterGUI::onStopClicked);
}

void ClearWaterGUI::updateReadings(double fm1, double fm2, double estTime, double actualTime, double deepakLevel, bool pumpOn)
{
    flow1Label->setText(QString("Flowmeter 1: %1 m³/hr").arg(fm1, 0, 'f', 2));
    flow2Label->setText(QString("Flowmeter 2: %1 m³/hr").arg(fm2, 0, 'f', 2));
    estTimeLabel->setText(QString("Estimated Time: %1 min").arg(estTime, 0, 'f', 2));
    actualTimeLabel->setText(QString("Actual Time: %1 min").arg(actualTime, 0, 'f', 2));
    deepakLevelLabel->setText(QString("Receiver Tank Level: %1 %").arg(deepakLevel, 0, 'f', 2));
    progressBar->setValue(static_cast<int>(deepakLevel));
    pumpStatusLabel->setText(pumpOn ? "Pump Status: ON ✅" : "Pump Status: OFF ❌");
}

void ClearWaterGUI::updatePumpStatus(bool on)
{
    pumpStatusLabel->setText(on ? "Pump Status: ON ✅" : "Pump Status: OFF ❌");
}

void ClearWaterGUI::onStartClicked()
{
    emit startRequested();
}

void ClearWaterGUI::onStopClicked()
{
    emit stopRequested();
}
