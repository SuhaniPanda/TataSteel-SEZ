#include "notifier.hpp"
#include <iostream>

void Notifier::sendAlert(const std::string& msg) {
    std::cout << "[🔔 Siemens Notification]: " << msg << "\n";
}
