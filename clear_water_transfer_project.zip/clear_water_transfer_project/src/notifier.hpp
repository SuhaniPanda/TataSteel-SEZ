#pragma once
#include <string>

class Notifier {
public:
    void sendAlert(const std::string& msg);
};
