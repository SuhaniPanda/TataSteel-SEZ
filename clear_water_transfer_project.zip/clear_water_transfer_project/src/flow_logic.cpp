#include "flow_logic.hpp"
#include <iostream>

double FlowLogic::detectLeak(double flow1, double flow2) {
    double diff = flow1 - flow2;
    if (diff > 5.0) {
        std::cout << "⚠️ Leak suspected. ΔFlow = " << diff << " m³/hr\n";
    }
    return diff;
}
