#pragma once

class SensorSimulator {
public:
    double getCWRLevel();         // Level from LT002
    double getFlow1();            // Flowmeter near WTP
    double getFlow2();            // Flowmeter near Deepak
    double getDeepakTankLevel();  // Deepak storage LT

private:
    double cwrLevel = 90.0;       // Starts at 90%
    double deepakLevel = 0.0;
};
