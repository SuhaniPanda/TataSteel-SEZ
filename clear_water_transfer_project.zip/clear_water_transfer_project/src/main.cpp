#include <iostream>
#include <fstream>
#include <QApplication>
#include <QTimer>

#include "flow_logic.hpp"
#include "ai_estimator.hpp"
#include "notifier.hpp"
#include "gui.hpp"
#include "../plc_sim/plc_interface.hpp"

class PumpController : public QObject {
    Q_OBJECT

public:
    PumpController(ClearWaterGUI *gui, QObject *parent = nullptr)
        : QObject(parent), gui(gui), minute(0), timer(new QTimer(this)), running(false) {
        connect(timer, &QTimer::timeout, this, &PumpController::simulateStep);
    }

public slots:
    void startPump() {
        if (!running) {
            logFile.open("../data/log.csv");
            logFile << "Minute,CWR_Level,Flow1,Flow2,Deepak_Level,Leak_Est,EstTime\n";
            minute = 0;
            running = true;
            timer->start(1000);
            std::cout << "✅ Pump started manually.\n";
        }
    }

    void stopPump() {
        running = false;
        timer->stop();

        if (logFile.is_open()) logFile.close();

        PLCData plc = PLCInterface::read();
        plc.pumpOn = false;
        PLCInterface::write(plc);

        gui->updatePumpStatus(false);
        std::cout << "🛑 Pump stopped.\n";
    }

private slots:
    void simulateStep() {
        if (minute >= 300 || !running) {
            stopPump();
            return;
        }

        PLCData plc = PLCInterface::read();

        if (plc.cwrLevel < 10.0 || plc.deepakLevel >= 100.0) {
            gui->updatePumpStatus(false);
            PLCInterface::write({plc.flow1, plc.flow2, plc.cwrLevel, plc.deepakLevel, false});
            Notifier notifier;
            std::string reason = (plc.cwrLevel < 10.0) ? "CWR Level Low" : "Deepak Tank Full";
            notifier.sendAlert("Pump Stopped: " + reason);
            stopPump();
            return;
        }

        // Compute logic
        double leak = flow.detectLeak(plc.flow1, plc.flow2);
        double est = ai.estimateTime(plc.flow2, plc.deepakLevel);
        ai.trackActualTime(plc.deepakLevel);

        // Update GUI and write log
        gui->updateReadings(plc.flow1, plc.flow2, est, ai.getActualTime(), plc.deepakLevel, true);
        logFile << minute++ << "," << plc.cwrLevel << "," << plc.flow1 << "," << plc.flow2 << ","
                << plc.deepakLevel << "," << leak << "," << est << "\n";

        // Update PLC
        plc.pumpOn = true;
        PLCInterface::write(plc);
    }

private:
    ClearWaterGUI *gui;
    QTimer *timer;
    int minute;
    bool running;
    std::ofstream logFile;
    FlowLogic flow;
    AIEstimator ai;
};

#include "main.moc"  // Needed if you're not using CMake's AUTOMOC

int main(int argc, char *argv[]) {
    QApplication app(argc, argv);
    ClearWaterGUI gui;
    PumpController controller(&gui);

    // Connect GUI buttons to pump logic
    QObject::connect(&gui, &ClearWaterGUI::startRequested, &controller, &PumpController::startPump);
    QObject::connect(&gui, &ClearWaterGUI::stopRequested, &controller, &PumpController::stopPump);

    gui.show();
    return app.exec();
}
