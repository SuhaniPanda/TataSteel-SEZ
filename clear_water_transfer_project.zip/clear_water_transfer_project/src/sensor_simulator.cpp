#include "sensor_simulator.hpp"
#include <cstdlib>

double SensorSimulator::getCWRLevel() {
    return cwrLevel -= 0.05; // Simulate usage
}

double SensorSimulator::getFlow1() {
    return 250.0 + (rand() % 10); // Simulate minor noise
}

double SensorSimulator::getFlow2() {
    return 245.0 + (rand() % 5); // Simulate slight loss
}

double SensorSimulator::getDeepakTankLevel() {
    deepakLevel += 0.3; // Simulate fill
    return deepakLevel;
}
