#ifndef AIESTIMATOR_HPP
#define AIESTIMATOR_HPP

class AIEstimator {
public:
    AIEstimator();

    double estimateTime(double flow2, double deepakLevel);
    void trackActualTime(double deepakLevel);
    double getActualTime() const;  // ✅ Add this line

private:
    double actualTime;
    double lastLevel;
};

#endif // AIESTIMATOR_HPP
