#pragma once
#include <string>

struct PLCData {
    double cwrLevel;
    double deepakLevel;
    double flow1;
    double flow2;
    bool pumpOn;
};

class PLCInterface {
public:
    static PLCData read();
    static void write(const PLCData &data);
};
