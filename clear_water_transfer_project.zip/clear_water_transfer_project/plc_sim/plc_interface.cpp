#include "plc_interface.hpp"
#include <fstream>
#include "json.hpp"

using json = nlohmann::json;
const std::string PLC_FILE = "../plc_sim/plc_memory.json";

PLCData PLCInterface::read() {
    std::ifstream file(PLC_FILE);
    PLCData data{0, 0, 0, 0, false};
    if (file) {
        json j;
        file >> j;
        data.cwrLevel = j["cwrLevel"];
        data.deepakLevel = j["deepakLevel"];
        data.flow1 = j["flow1"];
        data.flow2 = j["flow2"];
        data.pumpOn = j["pumpOn"];
    }
    return data;
}

void PLCInterface::write(const PLCData &data) {
    json j;
    j["cwrLevel"] = data.cwrLevel;
    j["deepakLevel"] = data.deepakLevel;
    j["flow1"] = data.flow1;
    j["flow2"] = data.flow2;
    j["pumpOn"] = data.pumpOn;

    std::ofstream file(PLC_FILE);
    file << j.dump(4);
}
