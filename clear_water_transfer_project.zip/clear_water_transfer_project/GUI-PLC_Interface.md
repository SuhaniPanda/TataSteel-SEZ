# GUI ↔ PLC Interface via Modbus

## Protocol: Modbus TCP
- GUI connects as client to 127.0.0.1:1502

## Address Map:
- Read Input Registers: Level, Flow1, Flow2
- Write Coils: PumpStart, Stop, Emergency

## How It Works:
1. Modbus Server runs as PLC simulator
2. GUI polls sensor data
3. GUI Start/Stop writes coil bits
4. GUI calculates AI logic locally

## Status Bits:
- Coil[0] = Pump ON
- Coil[1] = GUI Start
- Coil[2] = GUI Stop
- Coil[3] = Emergency STOP
