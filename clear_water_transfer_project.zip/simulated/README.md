# 💧 Clear Water Transfer Pump Automation System

## 📌 Overview
This project simulates and monitors the clear water transfer process from the WTP reservoir to Deepak Fertilizer via dual flowmeters, logic control, and AI-based time estimation. Built using C++ and Qt.

## 🖥️ Features
- Qt GUI with dark mode and logo branding
- Sensor simulation for CWR, Flow 1, Flow 2, Deepak Tank
- Leak detection logic
- AI estimation and actual tracking of tank fill time
- Manual Start/Stop control
- Real-time logging to CSV

## 🚀 Run Instructions
```bash
cd simulated
mkdir build && cd build
cmake ..
make
./clear_water_transfer
