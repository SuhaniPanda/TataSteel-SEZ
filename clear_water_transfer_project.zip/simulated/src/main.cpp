#include <iostream>
#include <thread>
#include <chrono>
#include <fstream>

#include <QApplication>
#include <QTimer>
#include <QMetaObject>

#include "sensor_simulator.hpp"
#include "flow_logic.hpp"
#include "ai_estimator.hpp"
#include "notifier.hpp"
#include "gui.hpp"

// 🔁 Manual control flag
bool pumpManualOff = false;

int main(int argc, char *argv[]) {
    QApplication app(argc, argv);
    ClearWaterGUI gui;
    gui.show();

    SensorSimulator sensors;
    FlowLogic flow;
    AIEstimator ai;
    Notifier notifier;

    std::ofstream logFile("../data/log.csv");
    logFile << "Minute,CWR_Level,Flow1,Flow2,Deepak_Level,Leak_Est,EstTime\n";

    int minute = 0;
    QTimer *timer = new QTimer();

    QObject::connect(timer, &QTimer::timeout, [&]() {
        if (minute >= 300) {
            timer->stop();
            logFile.close();
            return;
        }

        double cwr = sensors.getCWRLevel();
        double flow1 = sensors.getFlow1();
        double flow2 = sensors.getFlow2();
        double deepak = sensors.getDeepakTankLevel();

        std::cout << "\n⏱️ Minute " << minute << ":\n";
        std::cout << "CWR Level: " << cwr << "%\n";
        std::cout << "Flow 1: " << flow1 << " m³/hr\n";
        std::cout << "Flow 2: " << flow2 << " m³/hr\n";
        std::cout << "User Level: " << deepak << "%\n";

        // 🔴 Manual Stop or Safety Condition
        if (pumpManualOff || cwr < 10.0 || deepak >= 100.0) {
            std::cout << "🚫 Pump OFF\n";

            std::string reason = pumpManualOff ? "Manual Stop" :
                                 (cwr < 10.0 ? "CWR Level Low" : "User Tank Full");

            notifier.sendAlert("Pump Stopped: " + reason);
            gui.updatePumpStatus(false);
            minute++;  // still increment minute to reflect simulation
            return;
        }

        // ✅ Normal Operation
        std::cout << "✅ Pump ON\n";
        double leak = flow.detectLeak(flow1, flow2);
        double est = ai.estimateTime(flow2, deepak);
        ai.trackActualTime(deepak);

        logFile << minute << "," << cwr << "," << flow1 << "," << flow2 << "," << deepak << "," << leak << "," << est << "\n";

        gui.updateReadings(flow1, flow2, est, ai.getActualTime(), deepak, true);
        minute++;
    });

    timer->start(1000); // 1 simulated minute per real second
    return app.exec();
}
